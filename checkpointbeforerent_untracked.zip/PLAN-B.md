# PLAN-B: Full App Plan, Blueprints, Status, Risks

## Scope
- Date of review: February 19, 2026.
- Files reviewed: `README.md`, `FIX_REPORT.md`, `FIX_REPORT_DAILY_TRANSACTIONS.md`, `replit.md`, `main.py`, `app.py`, `models.py`, `tenancy.py`, `utils/module_loader.py`, `blueprints/*.py`, `templates/*.html`, `requirements.txt`, `errorlog.txt` (tail).
- Goal: one consolidated plan and blueprint of the current app, with working vs non-working features, faults/bugs, risks, orphan-data risks, and UI inconsistencies + improvements.

## System Blueprint
- Stack: Flask + Jinja2 + SQLAlchemy + SQLite. ORM models in `models.py` with tenant scoping and soft-delete flags on key tables.
- Entry points:
  - Runtime: `main.py` (full app, routes, background notifications, DB bootstrap).
  - App factory: `app.py` (uses `utils/module_loader.py` to auto-register blueprints).
- Multi-tenant model: `Tenant`, `tenant_id` on most tables, root user bypasses tenant enforcement (`tenancy.py`).
- Auth: Flask-Login with username/password, role field (`root`/`user` plus optional admin usage) and per-user permissions.
- Storage: SQLite at `instance/ahmed_cement.db`; uploads in `static/uploads`.
- Background worker: notification email sender thread in `main.py`.

## Module / Route Blueprint
Core routes in `main.py`:
- Auth: `/login`, `/logout`.
- Dashboard: `/` (index).
- Clients: `/clients`, `/add_client`, `/edit_client/<id>`, `/delete_client/<id>`, `/transfer_client/<id>`, `/reclaim_client/<id>`.
- Materials: `/materials`, `/add_material`, `/edit_material/<id>`, `/delete_material/<id>`, `/merge_materials`.
- Bookings: `/bookings`, `/add_booking`, `/edit_bill/Booking/<id>`.
- Direct sales: `/direct_sales`, `/add_direct_sale`, `/edit_bill/DirectSale/<id>`, `/add_sale`.
- Dispatching: `/dispatching`, `/add_record`, `/edit_entry/<id>`, `/delete_entry/<id>`, `/import_dispatch_data`.
- GRN: `/grn` (stock receiving).
- Payments: `/payments`, `/add_payment`, `/edit_bill/Payment/<id>`.
- Pending bills: `/pending_bills`, `/add_pending_bill`, `/edit_pending_bill/<id>`, `/delete_pending_bill/<id>`, `/toggle_bill_paid/<id>`.
- Ledger & reporting: `/ledger`, `/ledger/<client_id>`, `/financial_ledger/<client_id>`, `/decision_ledger`, `/material_ledger/<mat_id>`, `/client_ledger/<id>`, `/financial_details`.
- Notifications + follow-ups: `/notifications`, `/notifications/upcoming`, `/notifications/bill/<bill_id>`, and related API endpoints.
- Tenancy: `/tenants`, `/tenants/create`, `/tenants/<tenant_id>/reset_admin`, `/tenants/<tenant_id>/status`, `/tenants/<tenant_id>/delete`.
- Settings: `/settings`, `/add_user`, `/edit_user_permissions/<id>`, `/delete_user/<id>`, `/change_password`, `/update_settings`, data delete actions.
- Utility APIs: `/api/clients/search`, `/api/check_bill/<bill_no>`, `/api/client_booking_status/<client_code>`, `/api/client_financial_summary/<client_code>`.

Blueprints:
- Inventory (`blueprints/inventory.py`): `/inventory/stock_summary`, `/inventory/daily_transactions` with filters.
- Import/Export (`blueprints/import_export.py`): `/import_export` plus template download, import, and export endpoints.
- Data Lab (`blueprints/data_lab.py`): `/data_lab` upload, `/data_lab/basket`, `/data_lab/correct_bill`.
- Admin (`blueprints/admin.py`): `/admin` dashboard + module list + APIs (only auto-registered via `utils/module_loader.py`).

Redirects:
- `/stock_summary` -> `/inventory/stock_summary`.
- `/daily_transactions` -> `/inventory/daily_transactions`.

## Data Model Blueprint (Core Entities)
- Tenancy & auth: `Tenant`, `User`, `Role`, `Permission`, `UserRole`, `TenantFeature`, `AuditLog`.
- Inventory & sales:
  - `Material`, `Entry` (stock movements IN/OUT), `GRN` + `GRNItem`.
  - `Booking` + `BookingItem`, `DirectSale` + `DirectSaleItem`.
  - `Delivery` + `DeliveryItem` (legacy/outbound records).
- Finance: `PendingBill`, `Payment`, `Invoice`, `BillCounter`.
- Notifications: `FollowUpReminder`, `FollowUpContact`, `StaffEmail`.
- Data Lab: `ReconBasket`.

## Working Features (Based on Code + Fix Reports)
- Stock summary and daily transactions with filters (material/bill/client, date range) per `blueprints/inventory.py` and `FIX_REPORT_DAILY_TRANSACTIONS.md`.
- Dispatch import now skips missing/invalid dates rather than defaulting to today (`blueprints/import_export.py`).
- Pending bills & unpaid transactions flow aligned and tested per `FIX_REPORT.md`.
- Bookings, direct sales, GRN receiving, and dispatching flows are implemented in `main.py` and corresponding templates.
- Multi-tenant login, tenant status checks, and root access paths in `tenancy.py` and login logic in `main.py`.
- Notifications dashboard + due API and daily email worker exist in `main.py`.

## Non-Working / Broken / Incomplete
- Admin module renders missing templates (`admin_dashboard.html`, `admin_modules.html`) in `blueprints/admin.py`.
- Delivery persons UI route renders missing template (`delivery_persons.html`) in `main.py`.
- Data Lab uses invalid model field names and can error on POST (details below).
- `analyze_db.py` points to a hard-coded DB path that does not match this repo (`/home/claude/rv5/instance/ahmed_cement.db`).
- Orphan templates and legacy UI assets appear unused: `templates/base.html`, `templates/import_export.html`, `templates/receiving.html`, `templates/deliveries.html`.
- `blueprints/module_template.py` exists but is not referenced.

## Faults & Bugs (Concrete)
- Data Lab creates `Entry` with a non-existent field `client_name` (should be `client`) causing a `TypeError`. File: `blueprints/data_lab.py`.
- Data Lab creates `PendingBill` with a non-existent `date` field (model uses `created_at`). File: `blueprints/data_lab.py`.
- Data Lab routes lack `@login_required` and write to DB without authentication. File: `blueprints/data_lab.py`.
- Admin blueprint expects `admin_dashboard.html` and `admin_modules.html` but no templates exist, resulting in 500 errors when accessed. File: `blueprints/admin.py`.
- Delivery persons route returns missing `delivery_persons.html`. File: `main.py`.
- Sidebar active states are computed on `/stock_summary` and `/daily_transactions` but users are redirected to `/inventory/stock_summary` and `/inventory/daily_transactions`, so active highlighting won�t match. File: `templates/layout.html`.

## Risks
- Security:
  - No CSRF protection on POST routes (all forms are vulnerable to CSRF).
  - Optional open CORS + iframe allowance if `ALLOW_OPEN_CORS` is set (high risk in production).
  - Default root/admin passwords from environment if not overridden.
- Data integrity:
  - Many relations are stored as strings (client_code, material name, bill_no) with no FK constraints, so orphan/mismatched data can accumulate.
  - Tenant enforcement is applied on SELECTs; raw SQL updates and imports can bypass safeguards.
- Operational:
  - SQLite concurrency limits for multi-user use.
  - Background notification thread can duplicate in multi-process deployments.
- Performance:
  - String date/time fields on large `Entry` tables may slow filtering and sorting.

## Orphan Data / Data Hygiene Risks
- `Entry.client_code` without matching `Client.code`.
- `Entry.material` without matching `Material.name` (material master renamed/deleted).
- `PendingBill` without matching `Entry` records (or vice versa).
- `ReconBasket` rows accumulate without cleanup.
- `DeliveryPerson` values stored as strings in `Entry.driver_name` with no enforced link to `DeliveryPerson`.

## UI Inconsistencies
- Two UI systems exist (`templates/base.html` with Bootstrap 4 and `templates/layout.html` with Bootstrap 5). Base is likely unused but still present.
- Login page is a standalone style (not layout-based) and visually different from the main app.
- Multiple import/export templates (`import_export.html` and `import_export_new.html`) with unclear canonical path.
- Sidebar active state mismatch due to redirects (see bug list).

## UI Improvements (Concrete)
- Remove or migrate legacy templates to a single layout (`layout.html`).
- Fix sidebar active state by matching `/inventory/*` paths or using `url_for` consistently.
- Standardize form layouts (labels, spacing, validation messages) across pages.
- Add consistent empty states, loading states, and filter �Clear� actions.
- Normalize table density and button styles across financial and inventory pages.

## Plan (Prioritized)
1. Fix hard failures
   - Patch `blueprints/data_lab.py` to use correct model fields and require login.
   - Add missing templates or remove/disable admin and delivery-person routes.
2. Normalize UI
   - Remove or archive unused templates.
   - Fix sidebar active states and consolidate navigation paths.
3. Data hygiene tools
   - Add a script or admin tool to detect orphaned `Entry`/`PendingBill`/`Client`/`Material` links.
4. Security hardening
   - Add CSRF protection and tighten CORS / iframe settings by default.
   - Enforce strong default credentials and audit logs for critical actions.
5. Performance and reliability
   - Consider indexes for `Entry.date`, `Entry.client_code`, `PendingBill.bill_no`.
   - Consider switching date fields to proper `Date`/`DateTime` columns.
6. UX polish
   - Unify styling for login vs app shell.
   - Improve filters (chips, badges) and summary cards on dashboards.

## Upgrade Policy (Schema + Multi-Tenant Data Safety)
- Primary goal: keep all tenants data intact across schema changes, with safe rollback.
- Storage model: single SQLite DB with 	enant_id on tenant-scoped tables. New tables must include 	enant_id + indexes.
- Versioning: add a schema_version table (single row) to track applied migrations.
- Migration strategy: forward-only migrations with explicit rollback notes; avoid destructive changes without backfill.
- Backup policy (before any upgrade):
  - Full DB backup (copy instance/ahmed_cement.db).
  - Optional tenant-level export (CSV dumps per tenant_id for core tables).
- Upgrade steps (standard):
  1) Put app in maintenance mode (block writes).
  2) Create DB backup + record checksum.
  3) Run migration script(s) in order (DDL + data backfill).
  4) Verify: row counts + tenant_id integrity + smoke test core pages.
  5) Re-enable writes.
- New tables policy:
  - Include 	enant_id for all tenant-owned data.
  - Add indexes on (	enant_id, key fields like code, ill_no, date).
  - Seed data only for default tenant unless explicitly global.
- Data backfill policy:
  - If adding NOT NULL columns, backfill with safe defaults first, then enforce constraints.
  - For renamed fields, keep old column until data is copied and verified, then drop in a later migration.
- Restore policy (graceful):
  - If migration fails, restore DB from backup and reopen app.
  - If partial migration, use schema_version to detect and rerun from last safe point.
  - For tenant-level recovery, re-import tenant CSV exports into a clean DB if needed.


## Backup/Restore Assurance (Master Account Only)
- Scope: master/root admin performs backups and restores for the entire system (all tenants). Tenants do not run backups.
- Reason: upgrades affect shared schema and data. Any corruption or loss impacts all tenants and is unacceptable.
- Policy:
  - Only root user can initiate backup/restore.
  - Backups are full-DB and mandatory before any schema or code upgrade.
  - Restore is full-DB only; no partial restores during an upgrade window.
  - Maintenance mode required (no tenant writes).
  - Validation report stored with checksum + per-tenant table counts.
- Acceptance criteria (upgrade can proceed only if all pass):
  - Backup checksum recorded.
  - Restore rehearsal on a clone DB passes counts + integrity checks.
  - Smoke tests pass for core flows (login, daily transactions, dispatching, pending bills).


## Feature Proposal: Material Categories (Per-Tenant)
- Goal: allow each tenant to define their own material categories (e.g., Cement, Steel, Others).
- Model options:
  - Option A (recommended): new `MaterialCategory` table with `tenant_id`, `name`, `is_active`, timestamps. `Material` gains `category_id` FK.
  - Option B (simple): add `Material.category` string column. Lower integrity, faster to ship.
- UI:
  - Add Category management in Settings (add/edit/disable).
  - Add Category filter + display in Materials and Inventory pages.
- Data rules:
  - Categories are tenant-scoped; no cross-tenant sharing.
  - Materials can be uncategorized with a default �General.�
- Migration:
  - Backfill existing materials to `General` for each tenant.
